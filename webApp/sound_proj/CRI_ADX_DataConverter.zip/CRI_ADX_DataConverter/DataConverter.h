#pragma once
#include "DataManager.h"
#include <atomic>
#include <functional>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

class DataConverter final : public DataManager {
public:
    using Reporter = std::function<void(const std::wstring&)>;

    // Called from a GUI worker thread, not the GUI thread.
    bool ConvertFolder(const std::filesystem::path& acf,
                       const std::filesystem::path& folder,
                       const Reporter& report);
    void RequestCancel() noexcept { cancel_.store(true); }
    ~DataConverter() override;

private:
    static constexpr int kSampleRate = 48000;
    static constexpr int kChannels = 2;
    static constexpr int kFramesPerPull = 1024;
    static constexpr int kMaxCueSeconds = 12; // Long/looped cues are truncated.

    void PcmLoop();
    void BeginCapture();
    std::vector<float> EndCapture();
    void Cleanup();
    std::atomic<bool> pump_running_{false};
    std::atomic<bool> cancel_{false};
    std::thread pcm_thread_;
    std::mutex pcm_mutex_;
    bool capturing_ = false;
    bool overflow_ = false;
    std::vector<float> pcm_interleaved_; // capped to 12 sec in memory
};

#include "DataConverter.h"
#include <nlohmann/json.hpp>
#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <fstream>
#include <iomanip>
#include <limits>
#include <stdexcept>
#include <thread>

namespace fs = std::filesystem;
using nlohmann::json;
using namespace std::chrono_literals;

namespace {
// RIFF/WAVE PCM16, interleaved stereo, little endian (Windows/x86-64).
void WriteLE16(std::ostream& f, std::uint16_t x) {
    f.put(char(x)); f.put(char(x >> 8));
}
void WriteLE32(std::ostream& f, std::uint32_t x) {
    for (int i = 0; i < 4; ++i) f.put(char(x >> (8 * i)));
}
void SaveWav(const fs::path& path, const std::vector<float>& pcm, int sampleRate, int channels) {
    std::ofstream f(path, std::ios::binary);
    if (!f) throw std::runtime_error("WAV output file cannot be created");
    const auto bytes = static_cast<std::uint32_t>(pcm.size() * 2u);
    f.write("RIFF", 4); WriteLE32(f, bytes + 36);
    f.write("WAVEfmt ", 8);
    WriteLE32(f, 16); WriteLE16(f, 1); // PCM
    WriteLE16(f, static_cast<std::uint16_t>(channels));
    WriteLE32(f, sampleRate);
    WriteLE32(f, sampleRate * channels * 2);
    WriteLE16(f, static_cast<std::uint16_t>(channels * 2));
    WriteLE16(f, 16);
    f.write("data", 4); WriteLE32(f, bytes);
    for (float v : pcm) {
        const float clipped = std::clamp(v, -1.0f, 1.0f);
        const auto s = static_cast<std::int16_t>(std::lround(clipped * 32767.0f));
        WriteLE16(f, static_cast<std::uint16_t>(s));
    }
    if (!f) throw std::runtime_error("WAV writing failed");
}

json ExtractFeatures(const std::vector<float>& pcm, int sr, int channels) {
    const std::size_t frameCount = pcm.size() / static_cast<std::size_t>(channels);
    if (!frameCount) return {{"frames",0}, {"sample_rate",sr}};
    double sumSq=0.0, peak=0.0, zc=0.0;
    float prev=0.0f;
    const int window = sr / 50; // 20 ms windows
    double windowSq=0.0, windowRmsPrev=0.0;
    int windows=0, activeWindows=0, transients=0;

    for (std::size_t i=0;i<frameCount;++i) {
        double mono=0.0;
        for(int ch=0;ch<channels;++ch) {
            const double x=pcm[i*channels+ch];
            sumSq += x*x;
            peak = std::max(peak, std::abs(x));
            mono += x;
        }
        mono/=channels;
        if (i>0 && ((mono > 0.0001 && prev < -0.0001f) ||
                    (mono < -0.0001 && prev > 0.0001f))) ++zc;
        prev = static_cast<float>(mono);
        windowSq += mono*mono;
        if ((i+1) % window == 0 || i+1 == frameCount) {
            const int count = ((i+1) % window == 0) ? window : static_cast<int>((i+1) % window);
            const double wrms = std::sqrt(windowSq / std::max(1, count));
            if (wrms > 0.0031623) ++activeWindows; // -50 dBFS
            if (windows && wrms > 0.025 && wrms > windowRmsPrev * 2.8) ++transients;
            windowRmsPrev=wrms;
            ++windows;
            windowSq=0;
        }
    }
    const double rms=std::sqrt(sumSq / pcm.size());
    const double dbfs = 20.0*std::log10(std::max(rms, 1e-6));
    return {
      {"frames", frameCount},
      {"sample_rate", sr},
      {"channels", channels},
      {"captured_seconds", double(frameCount)/sr},
      {"rms", rms},
      {"rms_dbfs", dbfs},
      {"peak", peak},
      {"crest_factor_db", 20.0*std::log10(std::max(peak,1e-6)/std::max(rms,1e-6))},
      {"zero_crossing_rate", zc/double(frameCount)},
      {"active_ratio", windows ? double(activeWindows)/windows : 0.0},
      {"energy_rise_count_estimate", transients}
    };
}

std::string MeasuredDescription(const json& v) {
    if (v.value("frames", 0ull) == 0) return "PCMを取得できなかったため解析不可";
    const double db = v.value("rms_dbfs", -120.0);
    const double active = v.value("active_ratio", 0.0);
    std::string a = db < -40 ? "平均振幅が小さい" : (db < -18 ? "平均振幅は中程度" : "平均振幅が比較的大きい");
    a += active < 0.2 ? "。有音区間が短い" : (active < 0.7 ? "。無音と有音の区間が混在" : "。音が比較的持続");
    a += "。これはPCMから計算した数値的な特徴で、音源や楽器の種類を判別した文章ではない。";
    return a;
}

// Cues with non UTF-8 names can cause JSON encode failures; caller may need transcoding.
std::string ToUtf8Path(const fs::path& path) { return path.u8string(); }
}

DataConverter::~DataConverter() { Cleanup(); }

void DataConverter::BeginCapture() {
    std::lock_guard lock(pcm_mutex_);
    capturing_ = false;
    pcm_interleaved_.clear();
    pcm_interleaved_.reserve(std::size_t(kSampleRate) * kChannels * kMaxCueSeconds);
    overflow_ = false;
    capturing_ = true;
}

std::vector<float> DataConverter::EndCapture() {
    std::lock_guard lock(pcm_mutex_);
    capturing_ = false;
    return std::move(pcm_interleaved_);
}

void DataConverter::PcmLoop() {
    float left[kFramesPerPull]{}, right[kFramesPerPull]{};
    CriFloat32* buffers[2] = { left, right };
    while (pump_running_.load()) {
        const CriSint32 n = criAtomExAsr_GetPcmDataFloat32(
            kChannels, kFramesPerPull, buffers);
        if (n > 0) {
            std::lock_guard lock(pcm_mutex_);
            if (capturing_) {
                const std::size_t maxFloats = std::size_t(kSampleRate)*kChannels*kMaxCueSeconds;
                const std::size_t nFrames = std::min<std::size_t>(
                    n, (maxFloats - pcm_interleaved_.size()) / kChannels);
                for (std::size_t i = 0; i < nFrames; ++i) {
                    pcm_interleaved_.push_back(left[i]);
                    pcm_interleaved_.push_back(right[i]);
                }
                if (nFrames < static_cast<std::size_t>(n)) overflow_ = true;
            }
        }
        std::this_thread::sleep_for(8ms);
    }
}

void DataConverter::Cleanup() {
    // CRITICAL: Keep the PCM thread alive while voices / D-BAS are being destroyed.
    ReleasePlaybackResources();
    pump_running_.store(false);
    if (pcm_thread_.joinable()) pcm_thread_.join();
    FinalizeLibrary();
}

bool DataConverter::ConvertFolder(const fs::path& acf,
                                  const fs::path& folder,
                                  const Reporter& report) {
    cancel_.store(false);
    bool overallSuccess = false;
    try {
        if (!fs::exists(acf)) throw std::runtime_error("ACF not found");
        if (!fs::is_directory(folder)) throw std::runtime_error("ACB folder not found");
        if (!Initialize(acf)) throw std::runtime_error("CRI ADX initialization failed");

        pump_running_.store(true);
        pcm_thread_ = std::thread(&DataConverter::PcmLoop, this);

        const fs::path captures = folder / "captures";
        fs::create_directories(captures);
        json catalog = json::array();
        unsigned acbCount=0;
        unsigned cueCount=0;
        for (const auto& entry : fs::recursive_directory_iterator(folder)) {
            if (cancel_.load()) break;
            if (!entry.is_regular_file() || entry.path().extension() != ".acb") continue;
            const fs::path acbPath = entry.path();
            ++acbCount;
            report(L"ACBを読み込み中: " + acbPath.filename().wstring());
            fs::path awbPath = acbPath;
            awbPath.replace_extension(".awb");
            if (!fs::exists(awbPath)) awbPath.clear();
            if (!LoadAcb(acbPath, awbPath)) {
                catalog.push_back({{"acb",ToUtf8Path(acbPath)}, {"error","ACB load failed / wrong ACF or AWB"}});
                continue;
            }
            const CriSint32 numCues = criAtomExAcb_GetNumCues(acb_hn_);
            for (CriSint32 cueIndex=0; cueIndex<numCues && !cancel_.load(); ++cueIndex) {
                CriAtomExCueInfo info{};
                if (criAtomExAcb_GetCueInfoByIndex(acb_hn_, cueIndex, &info)!=CRI_TRUE) continue;
                ++cueCount;
                report(L"解析中: " + acbPath.filename().wstring() + L" / Cue #" + std::to_wstring(cueIndex));
                json record = {
                    {"acb_path", ToUtf8Path(acbPath)},
                    {"awb_path", awbPath.empty() ? "" : ToUtf8Path(awbPath)},
                    {"acf_path", ToUtf8Path(acf)},
                    {"cue_index", cueIndex},
                    {"cue_id", info.id},
                    {"cue_name", info.name ? info.name : ""},
                    {"user_data", info.user_data ? info.user_data : ""},
                    {"length_ms", info.length},
                    {"cue_type", static_cast<int>(info.type)},
                    {"num_tracks", info.num_tracks}
                };

                // Flush any PCM left in the renderer from the preceding cue.
                for (int j=0; j<50 && criAtomExAsr_GetNumBufferedSamples()>0 && !cancel_.load(); ++j)
                    std::this_thread::sleep_for(10ms);

                BeginCapture();
                criAtomExPlayer_SetCueId(player_, acb_hn_, info.id);
                const auto playId = criAtomExPlayer_Start(player_);
                if (playId == CRIATOMEX_INVALID_PLAYBACK_ID) {
                    record["error"] = "No playback voice / cannot start";
                    EndCapture();
                    catalog.push_back(record);
                    continue;
                }
                bool finished = false, failed = false;
                const auto startedAt = std::chrono::steady_clock::now();
                const auto timeLimit = std::chrono::seconds(kMaxCueSeconds) + 2s;
                while (!cancel_.load() && std::chrono::steady_clock::now()-startedAt < timeLimit) {
                    criAtomEx_ExecuteMain();
                    const auto status = criAtomExPlayer_GetStatus(player_);
                    if (status == CRIATOMEXPLAYER_STATUS_PLAYEND) { finished = true; break; }
                    if (status == CRIATOMEXPLAYER_STATUS_ERROR || status == CRIATOMEXPLAYER_STATUS_STOP) {
                        failed = true; break;
                    }
                    std::this_thread::sleep_for(10ms);
                }
                // PCM rendering may lag a little behind the player status.
                for (int j=0; j<30 && criAtomExAsr_GetNumBufferedSamples()>0 && !cancel_.load(); ++j)
                    std::this_thread::sleep_for(10ms);
                std::vector<float> pcm = EndCapture();
                criAtomExPlayer_Stop(player_);
                for (int j=0; j<30 && criAtomExAsr_GetNumBufferedSamples()>0; ++j)
                    std::this_thread::sleep_for(10ms);
                record["playback_completed"] = finished;
                record["truncated"] = !finished || overflow_;
                record["features"] = ExtractFeatures(pcm, kSampleRate, kChannels);
                record["description"] = MeasuredDescription(record["features"]);
                if (failed) record["error"] = "Playback error";
                if (!pcm.empty()) {
                    const fs::path wav = captures /
                        ("cue_" + std::to_string(acbCount) + "_" + std::to_string(cueIndex) + ".wav");
                    SaveWav(wav, pcm, kSampleRate, kChannels);
                    record["wav_path"] = ToUtf8Path(wav);
                }
                catalog.push_back(std::move(record));
            }
            ReleaseAcb();
        }
        const fs::path outPath = folder / "sound_catalog.json";
        std::ofstream output(outPath, std::ios::binary);
        if (!output) throw std::runtime_error("Cannot open JSON output");
        output << catalog.dump(2, ' ', false, json::error_handler_t::replace);
        if (!output) throw std::runtime_error("Cannot write JSON output");
        report(L"完了: ACB " + std::to_wstring(acbCount) + L"件 / Cue " +
               std::to_wstring(cueCount) + L"件。sound_catalog.json を出力しました。");
        overallSuccess = !cancel_.load();
    } catch (const std::exception& e) {
        // Console for SDK diagnostics; GUI receives a simple failure message.
        std::fprintf(stderr, "[DataConverter] %s\n", e.what());
        report(L"変換エラー（Visual Studioの出力/コンソールも確認してください）");
    }
    Cleanup();
    return overallSuccess;
}

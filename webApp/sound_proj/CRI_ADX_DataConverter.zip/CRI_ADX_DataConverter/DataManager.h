#pragma once
// CRI ADX Native SDK (Windows PC)
#include <cri_xpt.h>
#include <cri_atom_ex.h>
#include <cri_atom_pc.h>
#include <filesystem>
#include <string>

class DataManager {
public:
    DataManager() = default;
    virtual ~DataManager();
    DataManager(const DataManager&) = delete;
    DataManager& operator=(const DataManager&) = delete;

protected:
    // This example owns the CRI library exclusively; don't combine with a WASAPI manager.
    bool Initialize(const std::filesystem::path& acf);
    bool LoadAcb(const std::filesystem::path& acb,
                 const std::filesystem::path& awb = {});
    void ReleaseAcb();
    void ReleasePlaybackResources();  // Must be called while the PCM pulling thread is still running.
    void FinalizeLibrary();           // Call only after the pulling thread has stopped.
    void Shutdown();                  // Only when no PCM thread exists.

    CriAtomExPlayerHn player_ = nullptr;
    CriAtomExVoicePoolHn voice_pool_ = nullptr;
    CriAtomExAcbHn acb_hn_ = nullptr;

private:
    bool initialized_ = false;
    bool acf_registered_ = false;
    CriAtomDbasId dbas_id_ = CRIATOMDBAS_ILLEGAL_ID;
};

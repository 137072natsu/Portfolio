# CRI ADX DataConverter (Win32 + C++17)

This is a **source sample** for the CRI ADX Native SDK on Windows. It cannot be compiled or playback-tested here because the proprietary SDK libraries and your assets are not available.

## What it does

1. Select one `.acf` file and a folder that contains one or more `.acb` files.
2. Find `.acb` files recursively. If the same directory contains an `.awb` with the **same base name**, load it alongside the ACB.
3. Enumerate all Cues using `criAtomExAcb_GetNumCues` + `criAtomExAcb_GetCueInfoByIndex`.
4. For each Cue, start playback using its Cue **ID**, continuously pull **mixed output PCM** with `criAtomExAsr_GetPcmDataFloat32` from a separate thread, stop at Cue completion or cap capture around 12 s.
5. Save PCM as `captures/cue_<acb ordinal>_<cue index>.wav` and compute basic measurable audio features.
6. Write `sound_catalog.json` in the selected folder.

No audio is heard: `criAtomEx_InitializeForUserPcmOutput_PC` explicitly disables OS output. The WAV file can be listened to separately and/or sent to Python to ask a compatible audio-capable AI model about semantic content.

## Source files

- `DataManager.h/.cpp` CRI SDK initialization, ACF registration, ACB loading, player/voicepool/D-BAS management.
- `DataConverter.h/.cpp` derives from DataManager. PCM pull thread, WAV export, numeric feature extraction, JSON catalog.
- `main.cpp` native Win32 file selectors and Convert button; worker avoids hanging the UI.

## Visual Studio 2022 setup

1. Create a Windows Desktop **C++**, x64 project; enable **C++17**; disable precompiled headers (or adapt includes).
2. Add the five files. Set C/C++ > Additional Include Directories to the CRI ADX SDK's include directory and wherever `nlohmann/json.hpp` is installed.
3. Add the **matching x64 PC Native SDK** library folders under Linker > Additional Library Directories and the required `.lib` dependencies under Linker > Input. Follow your SDK's `user_pcm_output` or `playback_cue` sample project for exact filenames, since SDK packaging varies. Use the same runtime DLLs if needed.
4. Build as Unicode; this source uses `wWinMain`, Win32 and `#pragma comment` for `Comdlg32.lib`, `Shell32.lib`, `Ole32.lib`.
5. Choose an ACF *compatible with the selected ACBs*. Separate Atom Craft projects may require separate conversion runs with their own ACFs.
6. To avoid ambiguous CRI API file-name encodings, prefer basic ASCII for the directory and file names in this initial sample. Cue/user_data name strings may also need conversion from their SDK-specific encoding to UTF-8 before you index/search JSON.

## JSON example (illustrative ONLY)

```json
[
  {
    "acf_path": "SoundData/Project.acf",
    "acb_path": "SoundData/Ambient.acb",
    "awb_path": "",
    "cue_index": 0,
    "cue_id": 100,
    "cue_name": "Rain",
    "user_data": "",
    "length_ms": 4500,
    "cue_type": 0,
    "num_tracks": 1,
    "playback_completed": true,
    "truncated": false,
    "wav_path": "SoundData/captures/cue_1_0.wav",
    "features": {
      "frames": 216000,
      "sample_rate": 48000,
      "channels": 2,
      "captured_seconds": 4.5,
      "rms": 0.08,
      "rms_dbfs": -21.94,
      "peak": 0.7,
      "crest_factor_db": 18.84,
      "zero_crossing_rate": 0.12,
      "active_ratio": 0.85,
      "energy_rise_count_estimate": 4
    },
    "description": "平均振幅は中程度。音が比較的持続。..."
  }
]
```

RMS, peak, and ZCR are features of the **rendered stereo PCM**, not a robust classification of sound source or genre. Short-time rise count is a crude heuristic, *not* beat detection. Inferring "rain", "footsteps", instruments or mood requires separate semantic audio analysis on WAV, and results need human review.

## Important limitations

- This sample captures a **single Cue at a time** and avoids mixing other Cues, so ASR's master PCM can be attributed to the selected Cue. ACF DSP/bus effects influence the captured audio; custom routing could require additional setup.
- Each capture is bounded to **12 seconds**. Long/infinite-loop Cues are clipped and flagged `truncated`. A capture is also subject to a timeout or early playback errors.
- Current code matches external `.awb` files by the same base name. Projects using different AWB naming conventions or additional AWB slots need adjusted lookup/attach logic.
- Streaming, HCA-MX and surround audio behaviors depend on SDK and project. This sample configures standard ADX/HCA playback, 2-channel 48 kHz ASR output. `max_channels` and `max_sampling_rate` may need increases for your assets. Test short memory-loaded Cues first.
- Only use one library initialization mode at a time: **never initialize WASAPI and UserPCM in parallel in the same process**. If audible preview is essential, switch modes only after full finalize, or build a separate WASAPI preview application/process.
- The PCM pull thread must keep operating while player and voice pool handles are destroyed. The code preserves that ordering, stops/join the pump, and *then* finalizes the library. This follows the official deadlock warning.
- The ACF/ACB files are not themselves audio samples. **ACB** enumerates and plays Cues; **ACF** configures the Atom system; **AWB** may contain streamed wave data.
- SDK not provided; any compilation errors related to exact header exports, link dependencies, specific sound format, or narrow-path encoding must be resolved against your installed SDK version.

## Official manual references

- https://game.criware.jp/manual/native/adx2/latest/group__ATOMLIB__PC.html
- https://game.criware.jp/manual/native/adx2/latest/group__ATOMEXLIB__ASR.html
- https://game.criware.jp/manual/native/adx2/latest/group__ATOMEXLIB__ACB.html
- https://game.criware.jp/manual/native/adx2/latest/group__ATOMEXLIB__PLAYER.html

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <commdlg.h>
#include <shlobj.h>
#include "DataConverter.h"
#include <filesystem>
#include <memory>
#include <string>
#include <thread>

#pragma comment(lib, "Comdlg32.lib")
#pragma comment(lib, "Shell32.lib")
#pragma comment(lib, "Ole32.lib")

namespace fs = std::filesystem;
namespace {
constexpr UINT WM_CONVERTER_PROGRESS = WM_APP + 1;
constexpr UINT WM_CONVERTER_DONE = WM_APP + 2;
enum IDs { IDC_ACF=100, IDC_FOLDER, IDC_BROWSE_ACF, IDC_BROWSE_FOLDER, IDC_CONVERT, IDC_STATUS };
HWND gAcf = nullptr, gFolder = nullptr, gStatus = nullptr, gConvert = nullptr;
std::unique_ptr<DataConverter> gConverter;
std::thread gWorker;
bool gBusy = false, gCloseRequested = false;

std::wstring GetText(HWND edit) {
    const int count = GetWindowTextLengthW(edit);
    std::wstring s(static_cast<std::size_t>(count)+1, L'\0');
    GetWindowTextW(edit, s.data(), count+1);
    s.resize(count);
    return s;
}

void SetStatus(std::wstring_view text) {
    if (gStatus) SetWindowTextW(gStatus, std::wstring(text).c_str());
}

void SendProgress(HWND hwnd, const std::wstring& text) {
    // Win32 GUI must only be updated on its owning thread.
    auto* copy = new std::wstring(text);
    if (!PostMessageW(hwnd, WM_CONVERTER_PROGRESS, 0, reinterpret_cast<LPARAM>(copy))) {
        delete copy;
    }
}

void ChooseAcf(HWND hwnd) {
    wchar_t path[MAX_PATH] = L"";
    OPENFILENAMEW ofn{};
    ofn.lStructSize = sizeof(ofn);
    ofn.hwndOwner = hwnd;
    ofn.lpstrFile = path;
    ofn.nMaxFile = MAX_PATH;
    ofn.lpstrFilter = L"CRI ACF (*.acf)\0*.acf\0All files\0*.*\0\0";
    ofn.Flags = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST;
    if (GetOpenFileNameW(&ofn)) SetWindowTextW(gAcf, path);
}

void ChooseFolder(HWND hwnd) {
    BROWSEINFOW info{};
    info.hwndOwner = hwnd;
    info.lpszTitle = L"解析するACBファイルを含むフォルダー";
    info.ulFlags = BIF_RETURNONLYFSDIRS | BIF_NEWDIALOGSTYLE;
    PIDLIST_ABSOLUTE pidl = SHBrowseForFolderW(&info);
    if (!pidl) return;
    wchar_t path[MAX_PATH]{};
    if (SHGetPathFromIDListW(pidl, path)) SetWindowTextW(gFolder, path);
    CoTaskMemFree(pidl);
}

void StartConversion(HWND hwnd) {
    if (gBusy) return;
    const fs::path acf = GetText(gAcf);
    const fs::path folder = GetText(gFolder);
    if (!fs::is_regular_file(acf) || !fs::is_directory(folder)) {
        MessageBoxW(hwnd, L"ACFファイルとACBフォルダーを指定してください。", L"入力が必要", MB_OK | MB_ICONWARNING);
        return;
    }
    gConverter = std::make_unique<DataConverter>();
    gBusy = true;
    EnableWindow(gConvert, FALSE);
    SetStatus(L"PCM解析を開始しています...");
    auto* converter = gConverter.get();
    gWorker = std::thread([hwnd, converter, acf, folder] {
        const bool ok = converter->ConvertFolder(acf, folder,
            [hwnd](const std::wstring& s) { SendProgress(hwnd, s); });
        PostMessageW(hwnd, WM_CONVERTER_DONE, ok ? 1 : 0, 0);
    });
}

LRESULT CALLBACK WindowProc(HWND hwnd, UINT message, WPARAM wp, LPARAM lp) {
    switch (message) {
    case WM_CREATE: {
        auto add = [&](const wchar_t* type, const wchar_t* text, DWORD style,
                       int x, int y, int w, int h, int id) -> HWND {
            return CreateWindowExW(0, type, text, WS_CHILD | WS_VISIBLE | style,
                   x, y, w, h, hwnd, reinterpret_cast<HMENU>(static_cast<INT_PTR>(id)),
                   GetModuleHandleW(nullptr), nullptr);
        };
        add(L"STATIC", L"ACFファイル（ACBと同じAtom Craftプロジェクト）", 0, 16, 16, 420, 21, -1);
        gAcf = add(L"EDIT", L"", WS_BORDER | ES_AUTOHSCROLL, 16, 40, 545, 28, IDC_ACF);
        add(L"BUTTON", L"選択...", BS_PUSHBUTTON, 570, 40, 90, 28, IDC_BROWSE_ACF);
        add(L"STATIC", L"ACBフォルダー（サブフォルダーも検索）", 0, 16, 83, 420, 21, -1);
        gFolder = add(L"EDIT", L"", WS_BORDER | ES_AUTOHSCROLL, 16, 107, 545, 28, IDC_FOLDER);
        add(L"BUTTON", L"選択...", BS_PUSHBUTTON, 570, 107, 90, 28, IDC_BROWSE_FOLDER);
        gConvert = add(L"BUTTON", L"Cueを解析してJSON出力", BS_DEFPUSHBUTTON, 16, 157, 260, 38, IDC_CONVERT);
        add(L"STATIC", L"※ このモードではスピーカー出力しません。中止する場合は閉じるボタンを押してください。", 0, 16, 215, 650, 35, -1);
        gStatus = add(L"STATIC", L"待機中", SS_LEFT, 16, 267, 650, 70, IDC_STATUS);
        return 0;
    }
    case WM_COMMAND:
        switch (LOWORD(wp)) {
        case IDC_BROWSE_ACF: ChooseAcf(hwnd); return 0;
        case IDC_BROWSE_FOLDER: ChooseFolder(hwnd); return 0;
        case IDC_CONVERT: StartConversion(hwnd); return 0;
        }
        break;
    case WM_CONVERTER_PROGRESS: {
        std::unique_ptr<std::wstring> msg(reinterpret_cast<std::wstring*>(lp));
        if (msg) SetStatus(*msg);
        return 0;
    }
    case WM_CONVERTER_DONE:
        if (gWorker.joinable()) gWorker.join();
        gConverter.reset();
        gBusy = false;
        EnableWindow(gConvert, TRUE);
        if (gCloseRequested) {
            DestroyWindow(hwnd);
        } else if (!wp) {
            SetStatus(L"解析を中断または失敗しました。結果があればフォルダー内のJSONを確認してください。");
        }
        return 0;
    case WM_CLOSE:
        if (gBusy) {
            gCloseRequested = true;
            SetStatus(L"解析を中止して終了処理中...");
            if (gConverter) gConverter->RequestCancel();
            return 0;
        }
        DestroyWindow(hwnd);
        return 0;
    case WM_DESTROY:
        PostQuitMessage(0);
        return 0;
    }
    return DefWindowProcW(hwnd, message, wp, lp);
}
}

int WINAPI wWinMain(HINSTANCE instance, HINSTANCE, PWSTR, int show) {
    const wchar_t* cls = L"CriDataConverterWin32";
    WNDCLASSW wc{};
    wc.lpfnWndProc = WindowProc;
    wc.hInstance = instance;
    wc.lpszClassName = cls;
    wc.hCursor = LoadCursorW(nullptr, IDC_ARROW);
    wc.hbrBackground = reinterpret_cast<HBRUSH>(COLOR_WINDOW + 1);
    RegisterClassW(&wc);
    HWND hwnd = CreateWindowExW(0, cls, L"CRI ADX - ACB Cue Feature Exporter",
        WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT, 710, 405,
        nullptr, nullptr, instance, nullptr);
    if (!hwnd) return 1;
    ShowWindow(hwnd, show);
    MSG msg{};
    while (GetMessageW(&msg, nullptr, 0, 0)>0) {
        if (msg.message == WM_KEYDOWN && msg.wParam == VK_ESCAPE) {
            PostMessageW(hwnd, WM_CLOSE, 0, 0);
        }
        TranslateMessage(&msg);
        DispatchMessageW(&msg);
    }
    if (gWorker.joinable()) gWorker.join();
    return static_cast<int>(msg.wParam);
}

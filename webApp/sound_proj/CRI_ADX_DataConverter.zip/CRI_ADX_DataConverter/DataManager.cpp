#include "DataManager.h"
#include <cstdlib>
#include <cstdio>

namespace {
void* Alloc(void*, CriUint32 size) { return std::malloc(size); }
void Free(void*, void* p) { std::free(p); }

// CRI's file API accepts narrow paths. We use the Windows ANSI code page for a simple PC sample.
// Prefer ASCII-only directories, or adapt this to the character encoding required by your SDK.
std::string CriPath(const std::filesystem::path& path) {
    return path.string();
}
void OnCriError(const CriChar8* id, CriUint32 p1, CriUint32 p2, CriUint32*) {
    const auto* message = criErr_ConvertIdToMessage(id, p1, p2);
    if (message) std::fprintf(stderr, "[CRI ADX] %s\n", message);
}
}

DataManager::~DataManager() { Shutdown(); }

bool DataManager::Initialize(const std::filesystem::path& acf) {
    criErr_SetCallback(OnCriError);
    criAtomEx_SetUserAllocator(Alloc, Free, nullptr);

    CriAtomExConfigForUserPcmOutput config{};
    criAtomEx_SetDefaultConfigForUserPcmOutput(&config);
    constexpr int kSampleRate = 48000;
    constexpr int kChannels = 2;
    config.asr.output_sampling_rate = kSampleRate;
    config.asr.output_channels = kChannels;

    // Does not start WASAPI or produce audible sound.
    criAtomEx_InitializeForUserPcmOutput_PC(&config, nullptr, 0);
    initialized_ = true;

    dbas_id_ = criAtomDbas_Create(nullptr, nullptr, 0);
    if (dbas_id_ == CRIATOMDBAS_ILLEGAL_ID) {
        Shutdown();
        return false;
    }

    const std::string acfPath = CriPath(acf);
    if (criAtomEx_RegisterAcfFile(nullptr, acfPath.c_str(), nullptr, 0) != CRI_TRUE) {
        Shutdown();
        return false;
    }
    acf_registered_ = true;

    CriAtomExStandardVoicePoolConfig vp{};
    criAtomExVoicePool_SetDefaultConfigForStandardVoicePool(&vp);
    vp.player_config.streaming_flag = CRI_TRUE;
    vp.is_streaming_only = CRI_FALSE;   // Both memory playback and streaming.
    vp.player_config.max_channels = 2;
    vp.player_config.max_sampling_rate = 96000;
    vp.num_voices = 16;
    voice_pool_ = criAtomExVoicePool_AllocateStandardVoicePool(&vp, nullptr, 0);
    if (!voice_pool_) {
        Shutdown();
        return false;
    }

    player_ = criAtomExPlayer_Create(nullptr, nullptr, 0);
    if (!player_) {
        Shutdown();
        return false;
    }
    return true;
}

bool DataManager::LoadAcb(const std::filesystem::path& acb,
                          const std::filesystem::path& awb) {
    ReleaseAcb();
    const std::string a = CriPath(acb);
    const std::string w = awb.empty() ? std::string() : CriPath(awb);
    acb_hn_ = criAtomExAcb_LoadAcbFile(
        nullptr, a.c_str(), nullptr, w.empty() ? nullptr : w.c_str(), nullptr, 0);
    return acb_hn_ != nullptr;
}

void DataManager::ReleaseAcb() {
    if (player_) criAtomExPlayer_Stop(player_);
    if (acb_hn_) {
        criAtomExAcb_Release(acb_hn_);
        acb_hn_ = nullptr;
    }
}

void DataManager::ReleasePlaybackResources() {
    ReleaseAcb();
    if (player_) {
        criAtomExPlayer_Destroy(player_);
        player_ = nullptr;
    }
    if (voice_pool_) {
        criAtomExVoicePool_Free(voice_pool_);
        voice_pool_ = nullptr;
    }
    if (dbas_id_ != CRIATOMDBAS_ILLEGAL_ID) {
        criAtomDbas_Destroy(dbas_id_);
        dbas_id_ = CRIATOMDBAS_ILLEGAL_ID;
    }
    if (acf_registered_) {
        criAtomEx_UnregisterAcf();
        acf_registered_ = false;
    }
}

void DataManager::FinalizeLibrary() {
    if (initialized_) {
        criAtomEx_FinalizeForUserPcmOutput_PC();
        initialized_ = false;
        criErr_SetCallback(nullptr);
    }
}
void DataManager::Shutdown() {
    ReleasePlaybackResources();
    FinalizeLibrary();
}
